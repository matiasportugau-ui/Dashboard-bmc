# Kit SORA — BMC 10s (Vertical)
1) Subí a Sora: `assets/phone_home.png` (o `phone_scroll.mp4`) y `assets/grid_top_products.png`.
2) Pegá el prompt (ES o EN) en el editor.
3) Activá Storyboard con 4 tarjetas y asigná los assets según el archivo `docs/STORYBOARD.md`.
4) Duración 10 s, 9:16, 1080×1920, 30 fps. Pedí 3–4 variaciones.
5) Pasá el QA (`docs/QA_CHECKLIST.txt`) antes de publicar.