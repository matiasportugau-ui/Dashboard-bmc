# Storyboard — 4 tarjetas (recomendado para máximo control)

Tarjeta 1 (0–2.5 s) — HOOK
- Media: subir `assets/phone_home.png` o `assets/phone_scroll.mp4`
- Texto: “Comprá online — fácil”
- Nota: encuadrar el teléfono centrado; nada de rostro.

Tarjeta 2 (2.5–5 s) — PROOF (macro)
- Media: opcional `assets/macro_accessory.png` o sin media (Sora genera la macro)
- Texto: “Vélo y decidí mejor”
- Nota: enfatizar encastre/fijación real.

Tarjeta 3 (5–7.5 s) — AVAILABILITY
- Media: subir `assets/grid_top_products.png`
- Texto: “Stock permanente”
- Nota: flat‑lay ordenado, leve parallax.

Tarjeta 4 (7.5–10 s) — CTA
- Media: sin media (fondo limpio) o un color neutro.
- Texto XL: “bmcuruguay.com.uy”
- Footer pequeno: “Capturas reales del sitio. Imágenes ilustrativas.”

Sugerencias
- Dejá una pequeña separación entre tarjetas para transiciones limpias.
- Pedí 3–4 variaciones y elegí la mejor.