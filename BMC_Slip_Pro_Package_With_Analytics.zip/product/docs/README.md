# BMC Slip Pro — Plantilla de albarán/packing slip

Esta plantilla Liquid está pensada para tiendas Shopify que necesitan un **albarán profesional**, flexible y listo para su uso y distribución como producto digital. Incluye soporte para impresión en tamaño A4/Letter y, mediante una etiqueta (tag), un modo compacto para impresoras térmicas de 80 mm.

## Instalación

1. Acceda al panel de administración de Shopify.
2. Vaya a **Configuración → Envío y entrega → Documentos de envío**.
3. Seleccione **Plantilla de albarán** y reemplace el contenido con el archivo `src/packing-slip.liquid` de este paquete.
4. Guarde los cambios. La plantilla se aplicará a todos los pedidos que imprima desde **Pedidos → Más acciones → Imprimir albaranes**.

### Modo térmico

- Para activar el modo compacto (80 mm), añada el tag `termica` al pedido. El slip se adaptará automáticamente al ancho de la impresora térmica.
- Recuerde configurar la impresora con ancho de 80 mm (≈ 384 px), **Escala 100 %** y márgenes **Ninguno** en el cuadro de impresión.

### Fallback QR en PNG

- Por defecto, el slip utiliza un QR generado mediante SVG inline. Algunas impresoras térmicas de gama baja no renderizan SVG correctamente.
- Si tiene problemas con el QR, establezca la variable `use_png_qr` en `true` dentro del archivo Liquid y proporcione su propio código QR en formato base64 sustituyendo el valor de `src` en la etiqueta `<img>`.

## Personalización rápida

El archivo `packing-slip.liquid` contiene variables CSS definidas en el selector `:root`. Puede modificar colores y tipografías ajustando estos valores. Para un branding más completo, consulte el paquete opcional **Brand Skin Starter**.

## Estructura del paquete

```
product/
  src/
    packing-slip.liquid           Plantilla Liquid con soporte A4 y térmico.
  docs/
    README.md                     Este documento.
    CHANGELOG.md                  Historial de versiones y mejoras.
    LICENCE.txt                   Licencia de uso.
  analytics/
    PEC_result.json              Resultados de la evaluación objetiva (PEC).
    BAEM.json                    Autoauditoría del evaluador (BAEM).
  framework/
    prompt_maestro_unificado_v2.1.0.md   Marco operativo multi‑agente.
  config/
    config.example.json          Plantilla de configuración de proyecto.
  examples/
    notes.txt                    Carpeta para notas, capturas o ejemplos.
```

## Lectura de resultados analíticos

Los archivos en la carpeta `analytics` documentan la evaluación objetiva del slip.

- **PEC_result.json**: contiene las métricas de antes y después, el delta de mejora, el porcentaje de cierre de brecha y el ranking de factores clave.
- **BAEM.json**: describe la autoauditoría del evaluador con indicadores de robustez, fiabilidad y acciones recomendadas.

Puede abrir estos archivos en cualquier visor de JSON o importarlos en su herramienta preferida para profundizar en los resultados.

## Notas finales

Este paquete se proporciona bajo los términos de la licencia adjunta. Se anima a personalizar la plantilla para adaptarla a la identidad visual de su marca, manteniendo siempre las consideraciones de accesibilidad y legibilidad.