# Cadena Imagen (Banners/Renders → Realismo)

1) Análisis de composición → recorte/redistribución.  
2) Reencuadre inteligente a 1920×450.  
3) Limpieza/Generative Fill + texturas.  
4) Tipografía y CTA.  
5) Validación técnica (peso, formato, legibilidad).

# === EXPORT_SEAL v1 ===
# project: PromptPack Neutro
# prompt_id: NEUTRO::Cadena-Imagen.md
# version: v1.0.0
# file: Cadena-Imagen_NEUTRO.md
# lang: md
# created_at: 2025-09-06T08:41:10Z
# author: BMC / Usuario
# origin: chatgpt
# body_sha256: TBD
# notes: Versión neutralizada automáticamente
# === /EXPORT_SEAL ===
