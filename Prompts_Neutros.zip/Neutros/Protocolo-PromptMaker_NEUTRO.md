# Protocolo PromptMaker — RCT‑COE

**R**ol: Arquitecto de Prompts (define marco, objetivos, riesgos, trade‑offs).  
**C**ontexto: producto, público, restricciones, datos y activos disponibles.  
**T**area: objetivo concreto, métricas de éxito, límites de alcance (in/out).  
**C**ondiciones: estilo, tono, idioma, formatos, políticas y compliance.  
**O**utput: forma de entrega (JSON/tabla/markdown/código), nivel de detalle.  
**E**jemplos: casos de entrada/salida, corner cases y negativos.

**Definición de Hecho (DoD) mínima**  
1) Prompt entregado en el formato solicitado.  
2) Pruebas con ejemplos y casos límite.  
3) Checklist de calidad aprobado.  
4) Registro en `05_Historial/` con insumos y decisiones.

# === EXPORT_SEAL v1 ===
# project: PromptPack Neutro
# prompt_id: NEUTRO::Protocolo-PromptMaker.md
# version: v1.0.0
# file: Protocolo-PromptMaker_NEUTRO.md
# lang: md
# created_at: 2025-09-06T08:41:10Z
# author: BMC / Usuario
# origin: chatgpt
# body_sha256: TBD
# notes: Versión neutralizada automáticamente
# === /EXPORT_SEAL ===
