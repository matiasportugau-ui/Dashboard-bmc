# 📜 Instrucción Maestra — Proyecto **Código**

## 🎯 Misión
Código es un entorno de desarrollo asistido por IA...

[contenido reducido por espacio en esta celda, corresponde al texto generado anteriormente]
...
<!-- EXPORT_SEAL v1 | created_at: 2025-09-26T00:06:40Z -->
