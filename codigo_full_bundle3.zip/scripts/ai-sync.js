import fs from "node:fs"; import path from "node:path";
const files = ["README.md","config.yaml","prompts/maestro.md","prompts/politicas.md","prompts/prompt_reanudar_v2.2c.md"];
const dst = ".cursor/instructions"; const header="# Instrucciones — Sync Automático\n\n(No editar a mano)\n";
let body=header; for(const f of files){ if(fs.existsSync(f)){ const c=fs.readFileSync(f,"utf-8"); body+=`\n\n---\n## ${f}\n\n\`\`\`\n${c}\n\`\`\`\n`; } }
fs.mkdirSync(path.dirname(dst),{recursive:true}); fs.writeFileSync(dst, body, "utf-8"); console.log("Synced:", dst);
