import os, sys, yaml, json, logging
from pathlib import Path

class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({"level": record.levelname, "message": record.getMessage()}, ensure_ascii=False)

logger = logging.getLogger("codigo"); _h = logging.StreamHandler(sys.stdout); _h.setFormatter(JSONFormatter()); logger.addHandler(_h); logger.setLevel(logging.INFO)

def load_config(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f: cfg = yaml.safe_load(f)
    if (v:=os.getenv("COVERAGE_MIN")): cfg["analysis"]["coverage_min"] = int(v)
    if (v:=os.getenv("AUTOPILOT_ENABLED")) is not None: cfg["autopilot"]["enabled"] = v.lower()=="true"
    if (v:=os.getenv("APPROVAL_MODE")): cfg["autopilot"]["approval"]["mode"] = v
    Path(cfg["observability"]["logs_dir"]).mkdir(parents=True, exist_ok=True)
    return cfg
