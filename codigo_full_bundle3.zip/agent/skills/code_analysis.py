from pathlib import Path
import subprocess
from tools.runner import logger

def run(cmd: str):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    out, _ = p.communicate()
    return p.returncode, out

def run_scan(cfg) -> dict:
    repo_root = Path(cfg["project"]["repo_root"])
    results = {"linters": {}, "tree": [], "hotspots": cfg["analysis"]["hotspot_paths"]}
    for p in repo_root.rglob("*"):
        if any(x in p.parts for x in (".venv",".git","node_modules")): continue
        results["tree"].append(str(p))
    for l in cfg["analysis"]["linters"]:
        code, out = run(f"{l} .")
        results["linters"][l] = {"exit": code, "output": out[:2000]}
    logger.info("Análisis completado")
    return results
