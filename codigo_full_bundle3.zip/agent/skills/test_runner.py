import subprocess
from tools.runner import logger

def run_tests(cfg) -> bool:
    cmd = cfg["analysis"]["test_command"]; logger.info("Corriendo tests: %s", cmd)
    p = subprocess.Popen(cmd, shell=True); return p.wait() == 0
