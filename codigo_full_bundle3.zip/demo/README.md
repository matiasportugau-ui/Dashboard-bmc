# Demo de flujo

Este demo te guía por el flujo básico:
1. **scan**: se lista el árbol y se ejecutan linters configurados.
2. **propose**: genera `reports/PROPUESTAS.md` con ideas de refactor.
3. **apply**: crea rama `autocode/<timestamp>` y aplica un cambio seguro en `tools/runner.py`.
4. **test**: ejecuta pytest (si no hay tests, pasa sin cambios).
5. **report**: compila `reports/REPORTE.md`.

Para ejecutarlo manualmente:
```bash
python -m agent.main scan && python -m agent.main propose && python -m agent.main apply && python -m agent.main test && python -m agent.main report
```
O directamente:
```bash
npm run autopilot
```
<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:54:16Z -->
