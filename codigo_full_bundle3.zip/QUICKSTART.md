# QUICKSTART — Código (Autopilot listo)

## Sin comandos (solo con Cursor)
1. Abrí este proyecto en **Cursor**.
2. Ya tenés `.cursor/instructions` preconstruido con los prompts (incluye reanudar v2.2c).
3. Podés iniciar el ciclo desde la interfaz o con atajos:
   - **Ctrl+Shift+S** → regenerar instrucciones (si editás `prompts/` o `config.yaml`)
   - **Ctrl+K** → abrir chat con el asistente

## Con comandos (opcional)
```bash
# (opcional) si querés forzar el sync manual:
npm run ai:sync

# ciclo completo con autopilot (scan → propose → apply → test → report)
npm run autopilot
```

## Dónde ver resultados
- Los artefactos del agente se escriben en `reports/`:
  - `EVIDENCIA_ANALISIS.json`
  - `PROPUESTAS.md`
  - `REPORTE.md`

> Config por defecto: `AUTOPILOT_ENABLED=true` y `APPROVAL_MODE=auto_safe` en `config.yaml`.
<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:54:16Z -->
