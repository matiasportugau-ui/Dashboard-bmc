# Código — Bundle listo para usar

Subí y extraé este ZIP en la raíz del proyecto. Abre en Cursor.
- `npm run ai:sync` regenerará `.cursor/instructions` (ya te dejo una versión generada dentro del ZIP).
- `npm run autopilot` ejecuta el ciclo automáticamente.

<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:52:09Z -->
