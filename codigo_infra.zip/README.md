## Code — Entorno de desarrollo asistido por IA

Repositorio base para crear, automatizar y escalar proyectos con ayuda de agentes (GPT/Cursor).

### Qué incluye
- JS/TS: TypeScript, ESLint, Prettier
- Python: Ruff, pytest; agente de análisis/refactor
- Automatización: GitHub Actions
- Reproducibilidad: Dev Container
- Agentes: `.cursor/` y `prompts/`

### Scripts (npm)
- setup, ai:sync, scan, propose, apply, autopilot, report

<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z -->
