# Notice
Este repositorio utiliza la licencia MIT (ver `LICENSE`).

<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z -->
