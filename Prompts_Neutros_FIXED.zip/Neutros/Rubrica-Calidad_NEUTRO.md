# Rúbrica de Calidad (0–3)

1) Claridad y estructura (0–3)  
2) Cobertura de casos (0–3)  
3) Precisión técnica (0–3)  
4) Robustez a ruido (0–3)  
5) Utilidad del output (0–3)
<!-- 
=== EXPORT_SEAL v1 ===
project: PromptPack Neutro
prompt_id: NEUTRO::Rubrica-Calidad.md
version: v1.0.0
file: Rubrica-Calidad_NEUTRO.md
lang: md
created_at: 2025-09-06T08:41:10Z
author: BMC / Usuario
origin: chatgpt
body_sha256: TBD
notes: Versión neutralizada automáticamente
=== /EXPORT_SEAL === -->