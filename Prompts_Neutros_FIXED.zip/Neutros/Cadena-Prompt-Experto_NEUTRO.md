# Cadena: Prompt Experto (Modo Rápido)

1) Ingesta del caso con Plantilla **Brief-Caso**.  
2) Diseño del prompt con **Prompt-Blueprint** (RCT‑COE).  
3) Selección de **nivel de recursos** (1/2/3).  
4) Generación del prompt (modelo según recursos).  
5) QA con **Checklist‑QA** + rúbrica.  
6) Entrega en el formato solicitado + registro en `05_Historial/`.
<!-- 
=== EXPORT_SEAL v1 ===
project: PromptPack Neutro
prompt_id: NEUTRO::Cadena-Prompt-Experto.md
version: v1.0.0
file: Cadena-Prompt-Experto_NEUTRO.md
lang: md
created_at: 2025-09-06T08:41:10Z
author: BMC / Usuario
origin: chatgpt
body_sha256: TBD
notes: Versión neutralizada automáticamente
=== /EXPORT_SEAL === -->