# Políticas de Ingeniería — Código
- Cobertura mínima definida en config.yaml
- Evitar dependencias sin justificación
- Cambios grandes con feature flags
<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:52:09Z -->
