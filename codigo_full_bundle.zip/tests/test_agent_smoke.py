from tools.runner import load_config
def test_cfg():
    cfg = load_config(); assert "prompts" in cfg and "maestro" in cfg["prompts"]
