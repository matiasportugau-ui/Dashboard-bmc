Los artefactos de ejecución se generan aquí.
