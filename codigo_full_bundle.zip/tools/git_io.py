import subprocess
from datetime import datetime

def sh(cmd: str) -> str:
    return subprocess.check_output(cmd, shell=True, text=True).strip()

def create_work_branch(prefix: str) -> str:
    stamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S"); branch = f"{prefix}{stamp}"; sh(f"git checkout -b {branch}"); return branch

def stage_commit_change(path: str, message: str):
    sh(f"git add {path}"); sh(f'git commit -m "{message}"')
