import sys, json
from pathlib import Path
from tools.runner import load_config, logger
from agent.skills.code_analysis import run_scan
from agent.skills.refactor_apply import propose_changes, apply_changes
from agent.skills.test_runner import run_tests
from agent.skills.reporter import write_report

def ensure_reports_dir(cfg):
    Path(cfg["reporting"]["out_dir"]).mkdir(parents=True, exist_ok=True)

def cmd_scan(cfg):
    result = run_scan(cfg); ensure_reports_dir(cfg)
    (Path(cfg["reporting"]["out_dir"])/"EVIDENCIA_ANALISIS.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    logger.info("Scan completo.")

def cmd_propose(cfg):
    out = Path(cfg["reporting"]["out_dir"])/"PROPUESTAS.md"
    out.write_text(propose_changes(cfg), encoding="utf-8"); logger.info("Propuestas generadas.")

def cmd_apply(cfg):
    logger.info("Aplicando cambios…"); apply_changes(cfg)

def cmd_test(cfg):
    if not run_tests(cfg): sys.exit(1)

def cmd_report(cfg):
    write_report(cfg); logger.info("Reporte escrito.")

def cmd_autopilot(cfg): cmd_scan(cfg); cmd_propose(cfg); cmd_apply(cfg); cmd_test(cfg); cmd_report(cfg)
def cmd_ci(cfg):        cmd_autopilot(cfg)

def main():
    cfg = load_config(); ensure_reports_dir(cfg)
    cmd = (sys.argv[1] if len(sys.argv) > 1 else "scan").lower()
    mapping = dict(scan=cmd_scan, propose=cmd_propose, apply=cmd_apply, test=cmd_test, report=cmd_report, autopilot=cmd_autopilot, ci=cmd_ci)
    if cmd not in mapping: print(f"Comando desconocido: {cmd}", file=sys.stderr); sys.exit(2)
    mapping[cmd](cfg)

if __name__ == "__main__": main()
