from pathlib import Path
from tools.git_io import create_work_branch, stage_commit_change
from tools.runner import logger

def propose_changes(cfg) -> str:
    return "# Propuestas (auto)\n- Normalizar logs a JSON en tools/runner.py\n"

def apply_changes(cfg) -> list[str]:
    branch = create_work_branch(cfg["autopilot"]["safety"]["working_branch_prefix"])
    touched = []
    runner = Path("tools/runner.py")
    if runner.exists():
        txt = runner.read_text(encoding="utf-8")
        if "JSONFormatter" not in txt:
            txt = txt.replace("logging.Formatter(", "JSONFormatter(")
            runner.write_text(txt, encoding="utf-8")
            stage_commit_change(str(runner), "chore(logging): usar JSONFormatter por defecto")
            touched.append(str(runner))
    logger.info("Cambios aplicados en rama %s", branch)
    return touched
