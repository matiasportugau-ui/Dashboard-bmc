from pathlib import Path
import json
from tools.runner import logger

def write_report(cfg):
    out_dir = Path(cfg["reporting"]["out_dir"]); final = out_dir/"REPORTE.md"
    evid = out_dir/"EVIDENCIA_ANALISIS.json"; props = out_dir/"PROPUESTAS.md"
    lines = ["# Reporte de Código\n"]
    if evid.exists():
        data = json.loads(evid.read_text(encoding="utf-8")); lines.append("## Linters\n")
        for k, v in data.get("linters", {}).items():
            lines.append(f"- **{k}**: exit={v['exit']}")
    if props.exists(): lines += ["\n## Propuestas\n", props.read_text(encoding="utf-8")]
    final.write_text("\n".join(lines), encoding="utf-8"); logger.info("Reporte en %s", final)
