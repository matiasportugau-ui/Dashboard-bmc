# Guía rápida de uso — Prompt Maestro Universal

1. Copiar `Prompt_Maestro_FINAL.txt` como prompt base.
2. Ajustar `config.json` según el nuevo proyecto (KPIs, límites, toggles).
3. Ejecutar ciclo inicial (Plan V0) → registrar en logs/.
4. Mantener el loop QA (BLD↔CRT) según complejidad (3–5 ciclos típicos).
5. Consultar `CHANGELOG.md` y `metrics_summary.json` para métricas globales.
6. Reutilizar estructura para otros productos o proyectos.

Nota: versión final integra PEIPM y convergencia v2.1.0.
