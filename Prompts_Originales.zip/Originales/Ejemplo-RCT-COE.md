# Ejemplo RCT‑COE — Prompt Blueprint

**Rol**: Arquitecto de Prompts.  
**Contexto**: eCommerce, catálogos, FAQ, bots.  
**Tarea**: generar prompt para clasificar tickets por intención.  
**Condiciones**: español, JSON, top‑n labels con score.  
**Output**: JSON con `label`, `score`, `rationale`.  
**Ejemplos**:
- Positivo: "Necesito cotizar un galpón 10x20".  
- Negativo: "Gracias".
