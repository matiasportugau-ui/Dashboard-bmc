#!/usr/bin/env node
import { execSync } from "node:child_process";

const cmds = {
  setup: "bash scripts/bootstrap.sh && npm run prepare",
  scan: "npm run scan",
  propose: "npm run propose",
  apply: "npm run apply",
  autopilot: "npm run autopilot",
  report: "npm run report",
  "ai:sync": "npm run ai:sync",
  ci: "npm run ci",
  deploy: "node scripts/deploy.js"
};

const cmd = process.argv[2] || "scan";
if (!cmds[cmd]) {
  console.error(`Comando desconocido: ${cmd}`);
  process.exit(2);
}
execSync(cmds[cmd], { stdio: "inherit", env: process.env });

/* EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z */
