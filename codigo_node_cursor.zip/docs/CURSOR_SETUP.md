# Cursor — Setup para Código
1) Abrí el repo en Cursor.
2) Revisá `.cursor/rules` e `.cursor/instructions`.
3) Sincronizá instrucciones con `ai:sync` (atajo Ctrl+Shift+S).
4) Ejecutá el flujo: scan → propose → apply → test → report.

<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z -->
