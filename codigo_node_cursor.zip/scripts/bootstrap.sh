#!/usr/bin/env bash
set -euo pipefail

python3 -m venv .venv
source .venv/bin/activate
pip install -U pip pytest coverage ruff flake8 pyyaml

echo "Entorno listo. Probá: make scan"
# EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z
