import fs from "node:fs";
import path from "node:path";

const files = [
  "README.md",
  "config.yaml",
  "prompts/maestro.md",
  "prompts/politicas.md",
  "prompts/prompt_reanudar_v2.2c.md"
];

const dst = ".cursor/instructions";
const header =
  "# Instrucciones — Sync Automático\n\n" +
  "Este archivo fue generado por `npm run ai:sync`. No lo edites a mano.\n\n";

let body = header;
for (const f of files) {
  if (fs.existsSync(f)) {
    const rel = f;
    const content = fs.readFileSync(f, "utf-8");
    body += `\n\n---\n## ${rel}\n\n`;
    body += "```\n" + content + "\n```\n";
  }
}

fs.mkdirSync(path.dirname(dst), { recursive: true });
fs.writeFileSync(dst, body, "utf-8");
console.log("Cursor instructions synced:", dst);

/* EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z */
