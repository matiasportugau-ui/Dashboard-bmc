import { execSync } from "node:child_process";
import fs from "node:fs";

try {
  if (!fs.existsSync(".husky")) {
    execSync("npm run prepare", { stdio: "inherit" });
  }
  console.log("Setup base OK.");
} catch (e) {
  console.error("Error en setup:", e.message);
  process.exit(1);
}

/* EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z */
