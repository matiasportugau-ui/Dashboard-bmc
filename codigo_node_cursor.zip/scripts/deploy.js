console.log("Deploy stub: integra Vercel/Netlify/Railway/Heroku leyendo config YAML.");
process.exit(0);
/* EXPORT_SEAL v1 | created_at: 2025-09-25T23:32:41Z */
