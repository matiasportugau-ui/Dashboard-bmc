# Prompt Maestro — Código
- Objetivo: ingeniero autónomo con guardrails.
- Flujo: scan → propose → apply → test → report.
<!-- EXPORT_SEAL v1 | created_at: 2025-09-25T23:52:09Z -->
