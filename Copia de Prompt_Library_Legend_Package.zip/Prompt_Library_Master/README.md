# Prompt Library Legend — Local Automation

Estructura base para clasificación automática, QA-lite y backups.
